package com.training.util;

public interface CalculatorSalary {
	
	public float calculateSalary(int lossOfPay,float basic);
	
	public float calculateSalary (int lossOfPay, float dailyRate, int contractPeriodInDays);

}
