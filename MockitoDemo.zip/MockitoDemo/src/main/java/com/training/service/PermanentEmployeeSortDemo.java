package com.training.service;

public class PermanentEmployeeSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PermanentEmployeeService service =  new PermanentEmployeeService();
		System.out.println("printing all employess");
		
		service.getAllPermanentEmployees();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print employees after sorting");
		service.getAllPermanentEmployeesSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print employees after sorting based on salary");
		service.getAllPermanentEmployeesSortedByBasicSalary();
		

	}

}
