package com.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.PermanentEmployee;

public class PermanentEmployeeAddDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		///PermanentEmployeeService service = new PermanentEmployeeService();
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
						 
		PermanentEmployeeService service =  context.getBean("permanentEmployeeService",PermanentEmployeeService.class);
		
		
		service.addPermanentEmployee(new PermanentEmployee(1000,"Ram", "Developer",50000));
		
		service.addPermanentEmployee(new PermanentEmployee(1001,"Vivek", "Tech Lead",70000));
		
		//service.addPermanentEmployee(new PermanentEmployee(1001,"Vivek", "Tech Lead",70000));
		
		System.out.println("Printing all employees");	
		service.getAllPermanentEmployees();
		System.out.println("---------------------------------------------");	
		/*service.updatePermanentEmployee(new PermanentEmployee(1001,"Vivek", "Project Lead",100000));
		
		System.out.println("Printing all updated employees");	
		
		service.getAllPermanentEmployees();*/
	}

}
