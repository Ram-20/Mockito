package com.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PermanentEmployeeDeleteDemo {

	public static void main(String[] args) {
		
		//PermanentEmployeeService service =  new PermanentEmployeeService();
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
								 
		PermanentEmployeeService service =  context.getBean("permanentEmployeeService",PermanentEmployeeService.class);
		
		System.out.println();
		System.out.println("all employees are retrieved");
		
		service.getAllPermanentEmployees();
				
		service.deletePermanentEmployee(1000);
		service.deletePermanentEmployee(1001);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllPermanentEmployees();

	}

}
