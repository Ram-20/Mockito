package com.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.PermanentEmployee;

public class PermanentEmployeeUpdateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
								 
		PermanentEmployeeService service =  context.getBean("permanentEmployeeService",PermanentEmployeeService.class);
		
		service.updatePermanentEmployee(new PermanentEmployee(1000,"Ramasubramanian", "Developer",50000));
				
	}

}
