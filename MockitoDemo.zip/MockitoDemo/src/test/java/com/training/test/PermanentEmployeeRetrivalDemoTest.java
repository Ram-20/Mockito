package com.training.test;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.runners.ConsoleSpammingMockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;


import com.training.model.PermanentEmployee;
import com.training.service.PermanentEmployeeRetrivalDemo;
import com.training.service.PermanentEmployeeService;
import com.training.dataaccess.*;

@ContextConfiguration
@RunWith(ConsoleSpammingMockitoJUnitRunner.class)
public class PermanentEmployeeRetrivalDemoTest {
	
	
	@Mock
	private PermanentEmployeeDAO permanentEmployeeDAOImplMock;
	
	@InjectMocks
	private PermanentEmployeeService permanentEmployeeService;
	
	
	
	@Test 
	  public void testGetEmployeesWithSalaryGreaterThanFiftythousand() {
	  
	  
		PermanentEmployee e1 = new PermanentEmployee();
		e1.setBasicSalary(40000);
		PermanentEmployee e2 = new PermanentEmployee();
		e2.setBasicSalary(60000);
		PermanentEmployee e3 = new PermanentEmployee();
		e3.setBasicSalary(70000);
		
	  
	  List<PermanentEmployee> employees = new ArrayList<PermanentEmployee>();
	  
	  employees.add(e1);
	  employees.add(e2);
	  employees.add(e3);
	  
	  when(permanentEmployeeDAOImplMock.getAllPermanentEmployees()).thenReturn(employees);
	  
	  
	  
	  assertEquals(2,permanentEmployeeService.getAllPermanentEmployeesWithSalaryGreaterThanfiftythousand().size());
	  
	  
	  }

}
